# Hire Reactor Recruitment Manager — Production Deployment

## Recommended architecture

Browser (Chrome/Edge in VMware) → HTTPS web service → Flask/Gunicorn → PostgreSQL

Google Apps Script remains the controlled integration layer for Calendar and Gmail.

## Environment variables

Required:
- `HR_PRODUCTION=1`
- `HR_HTTPS=1`
- `HR_SECRET_KEY=<long random secret>`
- `HR_ADMIN_PASSWORD=<unique strong password>`
- `HR_INTEGRATION_TOKEN=<long random token>`
- `DATABASE_URL=<PostgreSQL connection string>`

Optional:
- `HR_REPLY_TO=interview@hirereactor.com`
- `HR_SENDER_NAME=Hire Reactor Recruitment`

## First deployment

1. Provision PostgreSQL.
2. Deploy the web service from this repository/container.
3. Run `flask --app app db init` only if the deployment has no migrations directory yet.
4. Generate and review the initial migration with `flask --app app db migrate -m "initial schema"`.
5. Run `flask --app app db upgrade`.
6. Run `HR_ADMIN_PASSWORD='...' python bootstrap.py`.
7. Verify `/health` returns database `ok`.
8. Log in and change/create recruiter accounts.
9. Import the existing Google Sheet A–M CSV.
10. Configure the Google Apps Script bridge with the production HTTPS URL and the same integration token.
11. Enable Calendar API advanced service and run `setupGoogleBridge()` once.
12. Validate one booking and one test email before using the integration for live recruiting.

## Backups

Run `scripts/backup_postgres.sh` daily through your hosting provider's scheduled job or an external scheduler. Keep provider-level automated backups enabled as well.

## Security

- Do not commit `.env` files or credentials.
- Use HTTPS only in production.
- Use a unique integration token shared only with the Apps Script project.
- Restrict admin access.
- Review audit logs periodically.
- Keep PostgreSQL private to the web service where supported.
- Use managed database backups and test restoration periodically.

## Google integration flow

### Candidate booking
Google Calendar booking → Calendar event → Apps Script Calendar trigger → incremental Calendar sync → candidate/application matching → `/api/calendar/event-sync` → Interview record.

### Recruiter email
ATS → `EMAIL_SEND` queue → Apps Script → Gmail → action completion callback.

The ATS never stores a Google password. Apps Script holds the Google authorization.
