# Hire Reactor Recruitment Management System — Final Production Release

A standalone browser-based recruitment management system built around Hire Reactor's existing Google Sheet data and recruiting workflow. It does not require an existing ATS.

## Production features
- Candidate master with email-first / phone-second duplicate matching.
- Multiple applications per candidate with complete history.
- Configurable recruitment stages, outcomes, sources, hard-rejection reasons and review reasons.
- Role-specific workflows and pipeline/Kanban view.
- Jobs, interviews, follow-ups and recruiter dashboard.
- Candidate search, filters, pagination and CSV export.
- Admin / Recruiter / Interviewer / Viewer roles.
- Login lockout, session timeout, CSRF protection, secure headers and audit logging.
- Google Sheet A–M import and authenticated Apps Script bridge.
- Google Calendar booking synchronization.
- Gmail interview-invite, follow-up and project-assignment queue.
- Idempotent integration actions to reduce duplicate Calendar events/emails.
- PostgreSQL-ready production deployment with Gunicorn/Docker.
- Flask-Migrate/Alembic production migration workflow.
- Render deployment blueprint included.
- PostgreSQL backup script included.

## Existing Sheet mapping
A Candidate Name | B Recommendation | C Salary | D Experience | E Email ID | F Phone Number | G Notice Period / Availability | H Status | I Link | J RP-Ticket | K Notes | L Date | M Time

The A–M sheet remains an import/integration surface. The application stores Candidate → Application → Event separately, so repeat applicants are preserved.

## Google Calendar behavior
When a candidate books through the configured Google Calendar booking page, the Apps Script bridge receives the Calendar update, performs incremental synchronization, matches the candidate using an application marker or candidate email, and updates/creates the interview record in the ATS.

## Email behavior
Recruiters can queue interview invitations, follow-ups and project/assessment assignments from a candidate profile. Apps Script polls the secure action queue and sends the message through the authorized Hire Reactor Gmail account. Each action is recorded in the ATS audit/integration history.

## Production boundary
This is a deployable production codebase, not an already-hosted public service. A live deployment still requires a hosting account, domain/DNS, TLS, PostgreSQL, secrets, backups and Google Workspace authorization. No Google credentials are embedded in this package.

## Local development
```bash
pip install -r requirements.txt
set HR_ADMIN_PASSWORD=change-me
python app.py
```

## Production
Use PostgreSQL, HTTPS, environment/secret management, automated backups, and `flask db upgrade`. Do not expose the Flask development server directly to the internet.

See `DEPLOYMENT.md` and `GOOGLE_INTEGRATION_SETUP.md`.
