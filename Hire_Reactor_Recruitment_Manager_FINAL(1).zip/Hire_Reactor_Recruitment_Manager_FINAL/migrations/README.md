# Database migrations

Production schema changes must be versioned with Flask-Migrate/Alembic.

Initial deployment:

```bash
flask --app app db init
flask --app app db migrate -m "initial schema"
flask --app app db upgrade
python bootstrap.py
```

After the first production migration is committed, every schema change must follow:

```bash
flask --app app db migrate -m "describe change"
flask --app app db upgrade
```

Never use `db.create_all()` against an existing production database as a substitute for migrations.
