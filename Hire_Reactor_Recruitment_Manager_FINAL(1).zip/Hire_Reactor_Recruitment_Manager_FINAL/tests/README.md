# Tests

Run from the project root after installing `requirements.txt`:

```bash
python -m unittest discover -s tests -v
```

The test suite is intentionally small and focuses on the core duplicate matching and recommendation rules. Add integration/browser tests in the deployment environment once PostgreSQL and Google Workspace are configured.
