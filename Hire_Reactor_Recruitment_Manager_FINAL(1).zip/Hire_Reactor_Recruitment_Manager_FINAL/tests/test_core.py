import os
import tempfile
import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

DB = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
DB.close()
os.environ['DATABASE_URL'] = 'sqlite:///' + DB.name
os.environ['HR_AUTO_INIT_DB'] = '1'
os.environ['HR_ADMIN_PASSWORD'] = 'TestPassword123!'
from app import app, db, Candidate, Application, Event, recommendation, norm_email, norm_phone

class CoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ctx = app.app_context(); cls.ctx.push(); db.drop_all(); db.create_all()
        c = Candidate(name='Test Candidate', email='Test@Example.com', normalized_email=norm_email('Test@Example.com'), phone='+91 98765 43210', normalized_phone=norm_phone('+91 98765 43210'))
        db.session.add(c); db.session.flush(); cls.c = c
    @classmethod
    def tearDownClass(cls):
        db.session.remove(); cls.ctx.pop(); os.unlink(DB.name)
    def test_normalization(self):
        self.assertEqual(norm_email(' Test@Example.COM '), 'test@example.com')
        self.assertEqual(norm_phone('+91 (98765) 43210'), '9876543210')
    def test_no_history_is_new(self):
        self.assertEqual(recommendation(self.c.id)[0], 'NEW')
    def test_hard_reason_is_do_not_proceed(self):
        a=Application(candidate_id=self.c.id, role='Developer', status='Rejected'); db.session.add(a); db.session.flush()
        db.session.add(Event(candidate_id=self.c.id, application_id=a.id, stage='Technical Assessment', outcome='Failed', reason='Technical Assessment Failed', event_date='2026-09-15'))
        db.session.commit()
        self.assertEqual(recommendation(self.c.id)[0], 'DO NOT PROCEED')

if __name__ == '__main__': unittest.main()
