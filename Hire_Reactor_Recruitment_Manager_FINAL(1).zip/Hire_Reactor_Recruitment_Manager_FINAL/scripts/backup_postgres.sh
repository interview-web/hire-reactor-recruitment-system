#!/usr/bin/env bash
set -euo pipefail
: "${DATABASE_URL:?DATABASE_URL is required}"
OUT_DIR="${BACKUP_DIR:-./backups}"
mkdir -p "$OUT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
pg_dump "$DATABASE_URL" --format=custom --file="$OUT_DIR/hire_reactor_${STAMP}.dump"
find "$OUT_DIR" -type f -name 'hire_reactor_*.dump' -mtime +30 -delete
echo "Backup created: $OUT_DIR/hire_reactor_${STAMP}.dump"
