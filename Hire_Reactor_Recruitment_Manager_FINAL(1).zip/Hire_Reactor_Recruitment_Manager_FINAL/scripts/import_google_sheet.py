"""Import an exported Google Sheet CSV into the Hire Reactor app database.
Run from the project directory after installing requirements:
    python scripts/import_google_sheet.py "Candidates 2026 - UI_UX Designer.csv"
"""
import csv, os, sys
from app import app, db, Candidate, Application, Event, find_candidate, norm_email, norm_phone, recommendation

if len(sys.argv) != 2:
    raise SystemExit("Usage: python scripts/import_google_sheet.py path/to/export.csv")
path = sys.argv[1]
with app.app_context():
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        reader = csv.DictReader(fh)
        imported = matched = skipped = 0
        for r in reader:
            name = (r.get("Candidate Name") or r.get("Candidate") or "").strip()
            if not name:
                skipped += 1; continue
            email = (r.get("Email ID") or r.get("Email") or "").strip()
            phone = (r.get("Phone Number") or r.get("Phone") or "").strip()
            c = find_candidate(email, phone)
            if c:
                matched += 1
            else:
                c = Candidate(name=name, email=email, normalized_email=norm_email(email), phone=phone, normalized_phone=norm_phone(phone))
                db.session.add(c); db.session.flush()
            c.email = c.email or email; c.normalized_email = norm_email(c.email)
            c.phone = c.phone or phone; c.normalized_phone = norm_phone(c.phone)
            a = Application(candidate_id=c.id, role=(r.get("Role") or "Imported").strip(), salary=r.get("Salary", ""),
                experience=r.get("Experience", ""), notice_period=r.get("Notice Period / Availability", ""),
                status=(r.get("Status") or "Imported").strip(), notes=r.get("Notes", ""),
                application_date=(r.get("Date") or "").strip(), source=r.get("Source") or "Imported CSV",
                rp_ticket=(r.get("RP-Ticket") or r.get("RP Ticket") or "").strip(), source_link=r.get("Link") or r.get("URL") or "")
            db.session.add(a); db.session.flush()
            rec, reason = recommendation(c.id); a.recommendation, a.recommendation_reason = rec, reason
            db.session.add(Event(candidate_id=c.id, application_id=a.id, stage=a.status, notes=a.notes,
                                 event_date=a.application_date, created_by="Google Sheet Import"))
            imported += 1
        db.session.commit()
        print(f"Imported applications: {imported}; matched existing candidates: {matched}; skipped blank rows: {skipped}")
