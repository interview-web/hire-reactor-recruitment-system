/**
 * Hire Reactor Recruitment Manager — Google Workspace Bridge v7
 *
 * This bridge keeps Google Calendar/Gmail automation in Apps Script while the
 * Hire Reactor web application remains the system of record.
 *
 * Setup:
 * 1) Deploy the Flask app with HTTPS.
 * 2) Set HR_WEB_APP_URL and HR_INTEGRATION_TOKEN below.
 * 3) Set HR_CALENDAR_ID to the calendar used for interview bookings.
 * 4) In Apps Script: Services -> add "Google Calendar API" (advanced service).
 * 5) Run setupGoogleBridge() once and approve permissions.
 *
 * Calendar flow:
 *   Calendar booking/change -> installable Calendar trigger -> incremental sync
 *   -> match by application marker or candidate email -> POST to web app
 *
 * Email flow:
 *   Recruiter clicks Send -> web app queues EMAIL_SEND -> this script polls
 *   queue -> GmailApp sends -> web app marks action DONE.
 *
 * Idempotency:
 *   Sent email/action IDs are stored in Script Properties before/after send so
 *   a temporary HTTP failure does not normally cause a duplicate email.
 */

const HR_WEB_APP_URL = 'https://YOUR-DOMAIN.example.com';
const HR_INTEGRATION_TOKEN = 'PUT-A-LONG-RANDOM-TOKEN-HERE';
const HR_CALENDAR_ID = 'primary';
const ACTION_BATCH_SIZE = 20;

function setupGoogleBridge() {
  const props = PropertiesService.getScriptProperties();
  props.setProperty('HR_CALENDAR_ID', HR_CALENDAR_ID);
  // Initial sync starts from now so old unrelated calendar history is not imported.
  if (!props.getProperty('HR_CALENDAR_SYNC_TOKEN')) {
    incrementalCalendarSync_();
  }
  removeTriggers_(['onCalendarChanged', 'processHireReactorActions']);
  ScriptApp.newTrigger('onCalendarChanged')
    .forUserCalendar(HR_CALENDAR_ID)
    .onEventUpdated()
    .create();
  ScriptApp.newTrigger('processHireReactorActions')
    .timeBased()
    .everyMinutes(5)
    .create();
  console.log('Hire Reactor Google bridge installed.');
}

function onCalendarChanged(e) {
  incrementalCalendarSync_();
}

function incrementalCalendarSync_() {
  const props = PropertiesService.getScriptProperties();
  const calendarId = props.getProperty('HR_CALENDAR_ID') || HR_CALENDAR_ID;
  let syncToken = props.getProperty('HR_CALENDAR_SYNC_TOKEN') || '';
  let pageToken = null;
  let newSyncToken = '';

  do {
    const params = {
      showDeleted: true,
      singleEvents: true,
      maxResults: 2500
    };
    if (pageToken) params.pageToken = pageToken;
    if (syncToken) {
      params.syncToken = syncToken;
    } else {
      params.timeMin = new Date().toISOString();
    }

    let response;
    try {
      response = Calendar.Events.list(calendarId, params);
    } catch (err) {
      // A sync token can expire. Rebuild it from the current time.
      if (syncToken) {
        props.deleteProperty('HR_CALENDAR_SYNC_TOKEN');
        return incrementalCalendarSync_();
      }
      throw err;
    }

    (response.items || []).forEach(function(event) {
      syncCalendarEvent_(event);
    });
    pageToken = response.nextPageToken || null;
    if (response.nextSyncToken) newSyncToken = response.nextSyncToken;
  } while (pageToken);

  if (newSyncToken) props.setProperty('HR_CALENDAR_SYNC_TOKEN', newSyncToken);
}

function syncCalendarEvent_(event) {
  if (!event || !event.id) return;

  const description = event.description || '';
  const applicationMatch = description.match(/Application ID:\s*(\d+)/i) || description.match(/HR-APP-ID:\s*(\d+)/i);
  const applicationId = applicationMatch ? applicationMatch[1] : '';
  const attendees = (event.attendees || []).map(function(a) { return a.email || ''; }).filter(Boolean);
  const organizer = event.organizer && event.organizer.email ? event.organizer.email : '';
  const candidateEmail = findCandidateEmail_(event, attendees, description, organizer);
  const start = event.start && (event.start.dateTime || event.start.date) ? (event.start.dateTime || event.start.date) : '';
  const end = event.end && (event.end.dateTime || event.end.date) ? (event.end.dateTime || event.end.date) : '';
  const meetingLink = event.hangoutLink || extractMeetingLink_(description);

  // Ignore all-day/non-interview events that contain no candidate signal.
  if (!applicationId && !candidateEmail) return;

  postJson_('/api/calendar/event-sync', {
    event_id: event.id,
    application_id: applicationId,
    candidate_email: candidateEmail,
    attendees: attendees,
    organizer: organizer,
    summary: event.summary || '',
    description: description,
    start: start,
    end: end,
    meeting_link: meetingLink,
    html_link: event.htmlLink || '',
    status: event.status || 'confirmed',
    interview_type: inferInterviewType_(event.summary || '')
  });
}

function findCandidateEmail_(event, attendees, description, organizer) {
  const ignored = {};
  if (organizer) ignored[String(organizer).toLowerCase()] = true;
  // Prefer a non-organizer attendee; this is normally the candidate on a booking event.
  for (let i = 0; i < attendees.length; i++) {
    const email = String(attendees[i]).toLowerCase();
    if (!ignored[email]) return attendees[i];
  }
  const match = description.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
  return match ? match[0] : '';
}

function inferInterviewType_(summary) {
  const s = String(summary || '').toLowerCase();
  if (s.includes('technical')) return 'Technical Interview';
  if (s.includes('final')) return 'Final Interview';
  if (s.includes('hr')) return 'HR Interview';
  return 'Interview';
}

function extractMeetingLink_(description) {
  const m = String(description || '').match(/https?:\/\/[^\s]+/i);
  return m ? m[0] : '';
}

function processHireReactorActions() {
  const data = getJson_('/api/actions/pull');
  (data.actions || []).forEach(function(action) {
    try {
      const saved = PropertiesService.getScriptProperties().getProperty('HR_DONE_ACTION_' + action.id);
      if (saved) {
        completeAction_(action.id, JSON.parse(saved));
        return;
      }

      let result;
      if (action.type === 'CALENDAR_CREATE') {
        result = createCalendarEvent_(action.id, action.payload);
      } else if (action.type === 'EMAIL_SEND') {
        result = sendEmailAction_(action.id, action.payload);
      } else {
        throw new Error('Unsupported action type: ' + action.type);
      }

      PropertiesService.getScriptProperties().setProperty('HR_DONE_ACTION_' + action.id, JSON.stringify(result));
      completeAction_(action.id, result);
    } catch (err) {
      failAction_(action.id, {error: String(err)});
    }
  });
}

function createCalendarEvent_(actionId, p) {
  if (!p.scheduled_at) throw new Error('scheduled_at is required');
  const props = PropertiesService.getScriptProperties();
  const existing = props.getProperty('HR_CALENDAR_ACTION_' + actionId);
  if (existing) return JSON.parse(existing);

  const start = new Date(p.scheduled_at);
  if (isNaN(start.getTime())) throw new Error('Invalid scheduled_at: ' + p.scheduled_at);
  const duration = Number(p.duration_minutes || 30);
  const end = new Date(start.getTime() + duration * 60000);
  const title = (p.interview_type || 'Interview') + ' — ' + (p.candidate_name || 'Candidate') + ' — ' + (p.role || 'Hire Reactor');
  const description = [
    'Candidate: ' + (p.candidate_name || ''),
    'Email: ' + (p.candidate_email || ''),
    'Role: ' + (p.role || ''),
    'Interviewer: ' + (p.interviewer || ''),
    'Meeting link: ' + (p.meeting_link || ''),
    'Application ID: ' + (p.application_id || ''),
    'HR-APP-ID: ' + (p.application_id || ''),
    'Hire Reactor Recruitment Manager'
  ].join('\n');
  const eventResource = {
    summary: title,
    description: description,
    start: {dateTime: start.toISOString()},
    end: {dateTime: end.toISOString()}
  };
  if (p.candidate_email) eventResource.attendees = [{email: p.candidate_email}];
  const event = Calendar.Events.insert(eventResource, HR_CALENDAR_ID, {sendUpdates: 'all'});
  const result = {calendar_event_id: event.id, html_link: event.htmlLink || ''};
  props.setProperty('HR_CALENDAR_ACTION_' + actionId, JSON.stringify(result));
  return result;
}

function sendEmailAction_(actionId, p) {
  if (!p.to) throw new Error('recipient is required');
  const props = PropertiesService.getScriptProperties();
  const existing = props.getProperty('HR_EMAIL_ACTION_' + actionId);
  if (existing) return JSON.parse(existing);

  const options = {
    htmlBody: p.html_body || '<p>' + escapeHtml_(p.text_body || '') + '</p>',
    name: p.sender_name || 'Hire Reactor Recruitment'
  };
  if (p.reply_to) options.replyTo = p.reply_to;
  GmailApp.sendEmail(p.to, p.subject || 'Hire Reactor Recruitment', p.text_body || stripHtml_(p.html_body || ''), options);
  const result = {sent: true, to: p.to, kind: p.kind || 'EMAIL_SEND', sent_at: new Date().toISOString()};
  props.setProperty('HR_EMAIL_ACTION_' + actionId, JSON.stringify(result));
  return result;
}

function completeAction_(id, result) {
  postJson_('/api/actions/' + id + '/complete', result);
}

function failAction_(id, result) {
  postJson_('/api/actions/' + id + '/fail', result);
}

function getJson_(path) {
  const response = UrlFetchApp.fetch(HR_WEB_APP_URL + path, {
    method: 'get',
    headers: {'X-HR-Integration-Token': HR_INTEGRATION_TOKEN},
    muteHttpExceptions: true
  });
  if (response.getResponseCode() !== 200) throw new Error('GET ' + path + ' failed: HTTP ' + response.getResponseCode() + ' ' + response.getContentText());
  return JSON.parse(response.getContentText() || '{}');
}

function postJson_(path, payload) {
  const response = UrlFetchApp.fetch(HR_WEB_APP_URL + path, {
    method: 'post',
    contentType: 'application/json',
    headers: {'X-HR-Integration-Token': HR_INTEGRATION_TOKEN},
    payload: JSON.stringify(payload || {}),
    muteHttpExceptions: true
  });
  if (response.getResponseCode() < 200 || response.getResponseCode() >= 300) {
    throw new Error('POST ' + path + ' failed: HTTP ' + response.getResponseCode() + ' ' + response.getContentText());
  }
  return JSON.parse(response.getContentText() || '{}');
}

function removeTriggers_(handlers) {
  ScriptApp.getProjectTriggers().forEach(function(trigger) {
    if (handlers.indexOf(trigger.getHandlerFunction()) >= 0) ScriptApp.deleteTrigger(trigger);
  });
}

function stripHtml_(html) {
  return String(html || '').replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&');
}

function escapeHtml_(text) {
  return String(text || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
