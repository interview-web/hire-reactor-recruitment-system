"""Bootstrap an already-migrated production database with required defaults.
Run after `flask --app app db upgrade`:
    python bootstrap.py
"""
import os
from werkzeug.security import generate_password_hash
from app import app, db, User, Setting, Workflow, WorkflowStage, DEFAULT_STAGES, DEFAULT_REASONS, DEFAULT_OUTCOMES, DEFAULT_SOURCES, DEFAULT_HARD_REASONS, DEFAULT_REVIEW_REASONS

with app.app_context():
    defaults = {
        "stages": DEFAULT_STAGES, "reasons": DEFAULT_REASONS, "outcomes": DEFAULT_OUTCOMES,
        "sources": DEFAULT_SOURCES, "hard_reasons": DEFAULT_HARD_REASONS, "review_reasons": DEFAULT_REVIEW_REASONS
    }
    for key, values in defaults.items():
        if not db.session.get(Setting, key):
            db.session.add(Setting(key=key, value="|".join(values)))
    if not User.query.filter_by(username="admin").first():
        password = os.environ.get("HR_ADMIN_PASSWORD")
        if not password:
            raise RuntimeError("HR_ADMIN_PASSWORD must be set")
        db.session.add(User(username="admin", password_hash=generate_password_hash(password), role="Admin"))
    if not Workflow.query.first():
        workflow = Workflow(name="Default Workflow")
        db.session.add(workflow)
        db.session.flush()
        for position, stage_name in enumerate(DEFAULT_STAGES):
            db.session.add(WorkflowStage(workflow_id=workflow.id, name=stage_name, position=position))
    db.session.commit()
    print("Production bootstrap complete.")
