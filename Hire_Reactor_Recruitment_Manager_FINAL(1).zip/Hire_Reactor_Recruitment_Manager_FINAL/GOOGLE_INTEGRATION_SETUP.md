# Google Calendar + Gmail integration

## What this patch does

### Candidate booking → Hire Reactor
1. Candidate books an interview using a Google Calendar booking page.
2. Google Calendar fires an installable event-updated trigger in Apps Script.
3. Apps Script performs an incremental Calendar API sync. Google documents that Calendar triggers signal that a sync is needed rather than identifying the exact event, so the bridge uses a stored sync token.
4. The bridge matches the event by the application marker when the web app created the event, otherwise by candidate email.
5. `/api/calendar/event-sync` creates or updates the Interview record.
6. The candidate page shows `Calendar synced`.

### Hire Reactor → candidate email
The recruiter can queue:
- Interview invitation
- Follow-up
- Project/assessment assignment

The web app creates an `EMAIL_SEND` integration action. Apps Script polls the queue, sends through the authorized Google account, and marks the action complete.

## One-time setup

1. Deploy the Flask application behind HTTPS.
2. Set `HR_INTEGRATION_TOKEN` in the server environment.
3. Open the Google Apps Script project.
4. Add the files in `google_apps_script/`.
5. Confirm `appsscript.json` is used as the Apps Script manifest.
6. Set:
   - `HR_WEB_APP_URL`
   - `HR_INTEGRATION_TOKEN`
   - `HR_CALENDAR_ID`
7. Run `setupGoogleBridge()` once and approve Google permissions.
8. Confirm the installable Calendar trigger and five-minute action trigger exist.

## Important matching behavior

The bridge does not assume every Calendar event is a recruitment interview. It only sends an event to the ATS when it has either:
- an application marker, or
- a candidate email that matches a candidate in Hire Reactor.

For events created by Hire Reactor, the description includes `Application ID` and `HR-APP-ID` so future edits remain linked to the exact application.

## Email safety

The bridge stores a per-action idempotency marker in Script Properties. If the web app temporarily fails to acknowledge a sent email, the bridge can complete the same action without intentionally sending it a second time.

## Google documentation

Google Calendar Apps Script triggers require incremental synchronization because the trigger does not identify the changed event. The Calendar advanced service is the supported mechanism for that synchronization.
