import csv
import io
import json
import os
import re
import secrets
from datetime import date, datetime, timedelta
from functools import wraps

from flask import Flask, abort, flash, jsonify, redirect, render_template, request, session, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import CSRFProtect
from flask_migrate import Migrate
from sqlalchemy import or_, func
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
os.makedirs(os.path.join(BASE, "data"), exist_ok=True)


def env_bool(name, default=False):
    value = os.environ.get(name)
    if value is None:
        return default
    return value.lower() in {"1", "true", "yes", "on"}


def database_url():
    url = os.environ.get("DATABASE_URL") or "sqlite:///" + os.path.join(BASE, "data", "recruitment.db")
    if url.startswith("postgres://"):
        url = "postgresql+psycopg://" + url[len("postgres://") :]
    elif url.startswith("postgresql://") and "+" not in url.split(":", 1)[0]:
        url = "postgresql+psycopg://" + url[len("postgresql://") :]
    return url


app = Flask(__name__)
secret = os.environ.get("HR_SECRET_KEY")
if not secret and env_bool("HR_PRODUCTION", False):
    raise RuntimeError("HR_SECRET_KEY must be set in production")
app.config.update(
    SECRET_KEY=secret or secrets.token_urlsafe(32),
    SQLALCHEMY_DATABASE_URI=database_url(),
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SQLALCHEMY_ENGINE_OPTIONS={"pool_pre_ping": True, "pool_recycle": 1800},
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=env_bool("HR_HTTPS", env_bool("HR_PRODUCTION", False)),
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    MAX_CONTENT_LENGTH=15 * 1024 * 1024,
    WTF_CSRF_TIME_LIMIT=None,
)
db = SQLAlchemy(app)
csrf = CSRFProtect(app)
migrate = Migrate(app, db)

DEFAULT_STAGES = [
    "New Application", "Invite Sent", "First Interview", "First Follow Up",
    "Second Follow Up", "Final Follow Up", "Technical Assessment",
    "Project Assessment", "Second Interview", "Final Interview", "Selected", "Rejected"
]
DEFAULT_REASONS = [
    "Interview No Show", "Interview Not Scheduled", "Project Assessment Not Submitted",
    "Project Assessment Failed", "Technical Assessment Failed", "Technical Interview Failed",
    "HR Interview Failed", "No Response", "Salary Mismatch", "Experience Mismatch",
    "Not Interested", "Candidate Withdrew", "Other"
]
DEFAULT_HARD_REASONS = [
    "Project Assessment Failed", "Technical Assessment Failed", "Technical Interview Failed",
    "HR Interview Failed", "Experience Mismatch", "Salary Mismatch"
]
DEFAULT_REVIEW_REASONS = [
    "Interview No Show", "Interview Not Scheduled", "Project Assessment Not Submitted",
    "No Response", "Candidate Withdrew"
]
DEFAULT_OUTCOMES = ["Pending", "Passed", "Failed", "Scheduled", "Completed", "Selected", "Rejected", "Withdrawn", "No Show"]
DEFAULT_SOURCES = ["Naukri", "LinkedIn", "Wellfound", "WhatsApp", "Referral", "Company Website", "Imported CSV", "Other"]
USER_ROLES = ["Admin", "Recruiter", "Interviewer", "Viewer"]


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), nullable=False, default="Recruiter")
    active = db.Column(db.Boolean, nullable=False, default=True)
    failed_logins = db.Column(db.Integer, nullable=False, default=0)
    locked_until = db.Column(db.DateTime)
    last_login_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class Setting(db.Model):
    key = db.Column(db.String(100), primary_key=True)
    value = db.Column(db.Text, nullable=False)


class Candidate(db.Model):
    __table_args__ = (db.Index("ix_candidate_email_phone", "normalized_email", "normalized_phone"),)
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False, index=True)
    email = db.Column(db.String(255), index=True)
    normalized_email = db.Column(db.String(255), index=True)
    phone = db.Column(db.String(80), index=True)
    normalized_phone = db.Column(db.String(30), index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class Workflow(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), unique=True, nullable=False)
    active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


class EmailTemplate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), unique=True, nullable=False)
    subject = db.Column(db.String(500), default="")
    html_body = db.Column(db.Text, default="")
    text_body = db.Column(db.Text, default="")
    active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class WorkflowStage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    workflow_id = db.Column(db.Integer, db.ForeignKey("workflow.id"), nullable=False, index=True)
    name = db.Column(db.String(160), nullable=False)
    position = db.Column(db.Integer, nullable=False, default=0)
    trigger_type = db.Column(db.String(40), default="manual")
    email_template_id = db.Column(db.Integer, db.ForeignKey("email_template.id"))
    calendar_required = db.Column(db.Boolean, nullable=False, default=False)
    duration_minutes = db.Column(db.Integer, nullable=False, default=30)
    active = db.Column(db.Boolean, nullable=False, default=True)
    workflow = db.relationship("Workflow", backref=db.backref("stages", lazy=True, order_by="WorkflowStage.position"))
    email_template = db.relationship("EmailTemplate")


class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False, index=True)
    location = db.Column(db.String(200))
    shift = db.Column(db.String(200))
    status = db.Column(db.String(30), nullable=False, default="Open", index=True)
    recruiter = db.Column(db.String(160))
    calendar_link = db.Column(db.String(500))
    jd_url = db.Column(db.String(500))
    assessment_url = db.Column(db.String(500))
    workflow_id = db.Column(db.Integer, db.ForeignKey("workflow.id"), index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    workflow = db.relationship("Workflow")
    applications = db.relationship("Application", back_populates="job", lazy=True)


class Application(db.Model):
    __table_args__ = (db.Index("ix_application_candidate_role_date", "candidate_id", "role", "application_date"),)
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidate.id"), nullable=False, index=True)
    job_id = db.Column(db.Integer, db.ForeignKey("job.id"), index=True)
    role = db.Column(db.String(200), index=True)
    salary = db.Column(db.String(100))
    experience = db.Column(db.String(100))
    notice_period = db.Column(db.String(100))
    status = db.Column(db.String(100), default="New Application", index=True)
    notes = db.Column(db.Text)
    application_date = db.Column(db.String(30), default=lambda: str(date.today()), index=True)
    source = db.Column(db.String(100), default="Naukri", index=True)
    rp_ticket = db.Column(db.String(160), index=True)
    source_link = db.Column(db.String(500))
    recommendation = db.Column(db.String(30), default="NEW", index=True)
    recommendation_reason = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    candidate = db.relationship("Candidate", backref=db.backref("applications", lazy=True))
    job = db.relationship("Job", back_populates="applications")


class Event(db.Model):
    __table_args__ = (db.Index("ix_event_candidate_date", "candidate_id", "event_date"),)
    id = db.Column(db.Integer, primary_key=True)
    candidate_id = db.Column(db.Integer, db.ForeignKey("candidate.id"), nullable=False, index=True)
    application_id = db.Column(db.Integer, db.ForeignKey("application.id"), index=True)
    stage = db.Column(db.String(120), nullable=False, index=True)
    outcome = db.Column(db.String(80), index=True)
    reason = db.Column(db.String(160), index=True)
    notes = db.Column(db.Text)
    event_date = db.Column(db.String(30), default=lambda: str(date.today()), index=True)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    application = db.relationship("Application")
    candidate = db.relationship("Candidate", backref=db.backref("events", lazy=True))


class Interview(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    application_id = db.Column(db.Integer, db.ForeignKey("application.id"), nullable=False, index=True)
    interview_type = db.Column(db.String(120))
    scheduled_at = db.Column(db.String(50), index=True)
    interviewer = db.Column(db.String(160))
    meeting_link = db.Column(db.String(500))
    status = db.Column(db.String(50), default="Scheduled", index=True)
    notes = db.Column(db.Text)
    calendar_event_id = db.Column(db.String(300))
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    application = db.relationship("Application")


class FollowUp(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    application_id = db.Column(db.Integer, db.ForeignKey("application.id"), nullable=False, index=True)
    due_date = db.Column(db.String(30), index=True)
    subject = db.Column(db.String(200))
    status = db.Column(db.String(50), default="Open", index=True)
    notes = db.Column(db.Text)
    assigned_to = db.Column(db.String(120), index=True)
    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    application = db.relationship("Application")


class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), index=True)
    action = db.Column(db.String(160), index=True)
    entity = db.Column(db.String(80), index=True)
    entity_id = db.Column(db.Integer)
    details = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)


class IntegrationAction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    action_type = db.Column(db.String(80), nullable=False, index=True)
    payload = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(30), default="PENDING", index=True)
    result = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    processed_at = db.Column(db.DateTime)
    attempts = db.Column(db.Integer, nullable=False, default=0)


# ---------- helpers ----------
def norm_email(value):
    return (value or "").strip().lower()


def norm_phone(value):
    digits = re.sub(r"\D", "", str(value or ""))
    return digits[-10:] if digits else ""


def setting_list(key, defaults):
    row = db.session.get(Setting, key)
    if not row:
        row = Setting(key=key, value="|".join(defaults))
        db.session.add(row)
        db.session.commit()
    return [x.strip() for x in row.value.split("|") if x.strip()]


def current_user():
    username = session.get("user")
    return User.query.filter_by(username=username, active=True).first() if username else None


def audit(action, entity, entity_id=None, details=""):
    db.session.add(AuditLog(username=session.get("user", "system"), action=action, entity=entity, entity_id=entity_id, details=details))


def integration_token():
    return os.environ.get("HR_INTEGRATION_TOKEN", "")


def valid_integration_token():
    token = request.headers.get("X-HR-Integration-Token", "")
    expected = integration_token()
    return bool(expected) and bool(token) and secrets.compare_digest(token, expected)


def find_candidate(email="", phone=""):
    e, p = norm_email(email), norm_phone(phone)
    if e:
        candidate = Candidate.query.filter_by(normalized_email=e).first()
        if candidate:
            return candidate
    if p and len(p) >= 7:
        candidate = Candidate.query.filter_by(normalized_phone=p).first()
        if candidate:
            return candidate
    return None


def history_for(candidate_id):
    return Event.query.filter_by(candidate_id=candidate_id).order_by(Event.event_date.desc(), Event.id.desc()).all()


def recommendation(candidate_id):
    history = history_for(candidate_id)
    if not history:
        return "NEW", "No previous recruitment history"
    latest = history[0]
    reason = (latest.reason or "").strip()
    outcome = (latest.outcome or "").strip().lower()
    hard = {x.lower() for x in setting_list("hard_reasons", DEFAULT_HARD_REASONS)}
    review = {x.lower() for x in setting_list("review_reasons", DEFAULT_REVIEW_REASONS)}
    if reason.lower() in hard:
        return "DO NOT PROCEED", f"Previous hard-fit rejection: {reason}"
    if reason.lower() in review:
        return "REVIEW", f"Previous process was incomplete: {reason}"
    if outcome in {"failed", "rejected"}:
        return "REVIEW", "Previous application ended negatively; recruiter review required"
    return "REVIEW", "Candidate has previous recruitment history; recruiter review required"


def refresh_application_recommendation(application):
    rec, reason = recommendation(application.candidate_id)
    application.recommendation = rec
    application.recommendation_reason = reason


def parse_date(value):
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except Exception:
        return None


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            session.pop("user", None)
            return redirect(url_for("login", next=request.path))
        session.permanent = True
        session["last_activity"] = datetime.utcnow().isoformat()
        return view(*args, **kwargs)
    return wrapped


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            me = current_user()
            if not me:
                return redirect(url_for("login"))
            if me.role not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


@app.context_processor
def inject_user():
    return {"me": current_user(), "today": date.today().isoformat()}


@app.before_request
def enforce_session_timeout():
    if request.endpoint in {"static", "login", "health"}:
        return
    if session.get("user"):
        last = session.get("last_activity")
        if last:
            try:
                if datetime.utcnow() - datetime.fromisoformat(last) > timedelta(hours=8):
                    session.clear()
                    flash("Your session expired. Please sign in again.", "error")
                    return redirect(url_for("login"))
            except ValueError:
                session.clear()


@app.after_request
def security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if request.is_secure or env_bool("HR_HTTPS", False):
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response


# ---------- auth ----------
@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = User.query.filter_by(username=username).first()
        now = datetime.utcnow()
        if user and user.locked_until and user.locked_until > now:
            flash("Account temporarily locked. Try again later.", "error")
        elif user and user.active and check_password_hash(user.password_hash, password):
            user.failed_logins = 0
            user.locked_until = None
            user.last_login_at = now
            db.session.commit()
            session.clear()
            session["user"] = user.username
            session.permanent = True
            session["last_activity"] = now.isoformat()
            audit("LOGIN", "User", user.id, "Successful login")
            db.session.commit()
            next_url = request.args.get("next") or request.form.get("next") or url_for("dashboard")
            if not next_url.startswith("/") or next_url.startswith("//"):
                next_url = url_for("dashboard")
            return redirect(next_url)
        else:
            if user:
                user.failed_logins += 1
                if user.failed_logins >= 5:
                    user.locked_until = now + timedelta(minutes=15)
            db.session.commit()
            flash("Invalid username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    username = session.get("user")
    if username:
        audit("LOGOUT", "User", None, username)
        db.session.commit()
    session.clear()
    return redirect(url_for("login"))


# ---------- dashboard ----------
@app.route("/")
@login_required
def dashboard():
    today = date.today().isoformat()
    stats = {
        "candidates": Candidate.query.count(),
        "applications": Application.query.count(),
        "open_jobs": Job.query.filter_by(status="Open").count(),
        "rejected": Application.query.filter_by(status="Rejected").count(),
        "upcoming": Interview.query.filter(Interview.status == "Scheduled").count(),
        "followups": FollowUp.query.filter_by(status="Open").count(),
        "overdue": FollowUp.query.filter(FollowUp.status == "Open", FollowUp.due_date < today).count(),
        "pending": IntegrationAction.query.filter_by(status="PENDING").count(),
    }
    recent = Application.query.order_by(Application.id.desc()).limit(12).all()
    overdue = FollowUp.query.filter(FollowUp.status == "Open", FollowUp.due_date < today).order_by(FollowUp.due_date.asc()).limit(10).all()
    return render_template("dashboard.html", stats=stats, recent=recent, overdue=overdue)


# ---------- candidates ----------
@app.route("/candidates")
@login_required
def candidates():
    q = request.args.get("q", "").strip()
    recommendation_filter = request.args.get("recommendation", "").strip()
    source = request.args.get("source", "").strip()
    status = request.args.get("status", "").strip()
    page = max(request.args.get("page", 1, type=int), 1)
    per_page = min(max(request.args.get("per_page", 25, type=int), 10), 100)
    query = Candidate.query
    if q:
        term = f"%{q}%"
        query = query.filter(or_(Candidate.name.ilike(term), Candidate.email.ilike(term), Candidate.phone.ilike(term)))
    if recommendation_filter:
        query = query.join(Application).filter(Application.recommendation == recommendation_filter).distinct()
    if source:
        query = query.join(Application).filter(Application.source == source).distinct()
    if status:
        query = query.join(Application).filter(Application.status == status).distinct()
    pagination = query.order_by(Candidate.updated_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    return render_template(
        "candidates.html", rows=pagination.items, pagination=pagination, q=q,
        sources=setting_list("sources", DEFAULT_SOURCES), stages=setting_list("stages", DEFAULT_STAGES),
        recommendations=["NEW", "REVIEW", "DO NOT PROCEED"], recommendation_filter=recommendation_filter, source_filter=source, status_filter=status
    )


@app.route("/candidate/add", methods=["GET", "POST"])
@login_required
@role_required("Admin", "Recruiter")
def add_candidate():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        phone = request.form.get("phone", "").strip()
        if not name:
            flash("Candidate name is required.", "error")
            return redirect(url_for("add_candidate"))
        existing = find_candidate(email, phone)
        if existing:
            flash(f"Candidate already exists as {existing.name}. Open the existing profile instead of creating a duplicate.", "error")
            return redirect(url_for("candidate", cid=existing.id))
        c = Candidate(name=name, email=email, normalized_email=norm_email(email), phone=phone, normalized_phone=norm_phone(phone))
        db.session.add(c)
        db.session.flush()
        audit("CREATE", "Candidate", c.id, c.name)
        db.session.commit()
        return redirect(url_for("candidate", cid=c.id))
    return render_template("add_candidate.html")


@app.route("/candidate/<int:cid>")
@login_required
def candidate(cid):
    c = Candidate.query.get_or_404(cid)
    apps = Application.query.filter_by(candidate_id=cid).order_by(Application.id.desc()).all()
    events = history_for(cid)
    interviews = Interview.query.join(Application).filter(Application.candidate_id == cid).order_by(Interview.scheduled_at.desc(), Interview.id.desc()).all()
    followups = FollowUp.query.join(Application).filter(Application.candidate_id == cid).order_by(FollowUp.status.asc(), FollowUp.due_date.asc()).all()
    rec = recommendation(cid)
    jobs = Job.query.filter_by(status="Open").order_by(Job.title).all()
    return render_template("candidate.html", c=c, apps=apps, events=events, interviews=interviews, followups=followups, rec=rec,
                           jobs=jobs, stages=setting_list("stages", DEFAULT_STAGES), outcomes=setting_list("outcomes", DEFAULT_OUTCOMES),
                           reasons=setting_list("reasons", DEFAULT_REASONS), sources=setting_list("sources", DEFAULT_SOURCES))


@app.route("/candidate/<int:cid>/edit", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def edit_candidate(cid):
    c = Candidate.query.get_or_404(cid)
    email = request.form.get("email", "").strip()
    phone = request.form.get("phone", "").strip()
    duplicate = find_candidate(email, phone)
    if duplicate and duplicate.id != c.id:
        flash("Another candidate already uses that email or phone.", "error")
        return redirect(url_for("candidate", cid=cid))
    c.name = request.form.get("name", c.name).strip() or c.name
    c.email = email
    c.normalized_email = norm_email(email)
    c.phone = phone
    c.normalized_phone = norm_phone(phone)
    audit("UPDATE", "Candidate", cid, "Profile updated")
    db.session.commit()
    flash("Candidate profile updated.")
    return redirect(url_for("candidate", cid=cid))


@app.route("/candidate/<int:cid>/application", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def add_application(cid):
    c = Candidate.query.get_or_404(cid)
    job_id = request.form.get("job_id") or None
    role = request.form.get("role", "").strip()
    job = Job.query.get(job_id) if job_id else None
    if job:
        role = job.title
    if not role:
        flash("Select a job or enter a role.", "error")
        return redirect(url_for("candidate", cid=cid))
    rec, reason = recommendation(cid)
    a = Application(
        candidate_id=cid, job_id=job_id, role=role, salary=request.form.get("salary", ""),
        experience=request.form.get("experience", ""), notice_period=request.form.get("notice", ""),
        status=request.form.get("status") or setting_list("stages", DEFAULT_STAGES)[0], notes=request.form.get("notes", ""),
        application_date=request.form.get("application_date") or str(date.today()), source=request.form.get("source") or "Naukri",
        rp_ticket=request.form.get("rp_ticket", "").strip(), source_link=request.form.get("source_link", "").strip(),
        recommendation=rec, recommendation_reason=reason
    )
    db.session.add(a)
    db.session.flush()
    audit("CREATE", "Application", a.id, f"Candidate {cid} / {role} / {rec}")
    db.session.commit()
    flash("New application added. Previous candidate history remains linked.")
    return redirect(url_for("candidate", cid=cid))


@app.route("/candidate/<int:cid>/application/<int:aid>/edit", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def edit_application(cid, aid):
    a = Application.query.get_or_404(aid)
    if a.candidate_id != cid:
        abort(400)
    a.salary = request.form.get("salary", "")
    a.experience = request.form.get("experience", "")
    a.notice_period = request.form.get("notice", "")
    a.status = request.form.get("status", a.status)
    a.notes = request.form.get("notes", "")
    a.source = request.form.get("source", a.source)
    a.rp_ticket = request.form.get("rp_ticket", "").strip()
    a.source_link = request.form.get("source_link", "").strip()
    refresh_application_recommendation(a)
    audit("UPDATE", "Application", aid, f"Status {a.status}")
    db.session.commit()
    flash("Application updated.")
    return redirect(url_for("candidate", cid=cid))


@app.route("/candidate/<int:cid>/event", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter", "Interviewer")
def add_event(cid):
    Candidate.query.get_or_404(cid)
    app_id = request.form.get("application_id") or None
    if app_id:
        a = Application.query.get_or_404(app_id)
        if a.candidate_id != cid:
            abort(400)
    stage = request.form.get("stage", "").strip()
    if not stage:
        flash("Stage is required.", "error")
        return redirect(url_for("candidate", cid=cid))
    e = Event(candidate_id=cid, application_id=app_id, stage=stage, outcome=request.form.get("outcome", ""),
              reason=request.form.get("reason", ""), notes=request.form.get("notes", ""),
              event_date=request.form.get("event_date") or str(date.today()), created_by=session["user"])
    db.session.add(e)
    if app_id:
        a.status = stage
        refresh_application_recommendation(a)
    db.session.flush()
    audit("CREATE", "Event", e.id, f"Candidate {cid}: {stage}")
    db.session.commit()
    flash("Recruitment history updated.")
    return redirect(url_for("candidate", cid=cid))


@app.route("/candidate/<int:cid>/interview", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def add_interview(cid):
    a = Application.query.get_or_404(request.form["application_id"])
    if a.candidate_id != cid:
        abort(400)
    i = Interview(application_id=a.id, interview_type=request.form.get("interview_type", "Interview"),
                  scheduled_at=request.form.get("scheduled_at", ""), interviewer=request.form.get("interviewer", ""),
                  meeting_link=request.form.get("meeting_link", ""), status=request.form.get("status", "Scheduled"),
                  notes=request.form.get("notes", ""), created_by=session["user"])
    db.session.add(i)
    db.session.flush()
    if i.status == "Scheduled":
        queue_action("CALENDAR_CREATE", {
            "interview_id": i.id, "application_id": a.id, "candidate_id": cid,
            "candidate_name": a.candidate.name, "candidate_email": a.candidate.email,
            "role": a.role, "scheduled_at": i.scheduled_at, "interviewer": i.interviewer,
            "meeting_link": i.meeting_link, "interview_type": i.interview_type,
        })
    audit("CREATE", "Interview", i.id, f"Application {a.id}")
    db.session.commit()
    flash("Interview saved and calendar action queued.")
    return redirect(url_for("candidate", cid=cid))


@app.route("/candidate/<int:cid>/followup", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def add_followup(cid):
    a = Application.query.get_or_404(request.form["application_id"])
    if a.candidate_id != cid:
        abort(400)
    f = FollowUp(application_id=a.id, due_date=request.form.get("due_date", ""), subject=request.form.get("subject", "Candidate follow-up"),
                 status="Open", notes=request.form.get("notes", ""), assigned_to=request.form.get("assigned_to", ""), created_by=session["user"])
    db.session.add(f)
    db.session.flush()
    audit("CREATE", "FollowUp", f.id, f"Application {a.id}")
    db.session.commit()
    flash("Follow-up task created.")
    return redirect(url_for("candidate", cid=cid))


@app.route("/followup/<int:fid>/complete", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def complete_followup(fid):
    f = FollowUp.query.get_or_404(fid)
    f.status = "Completed"
    audit("UPDATE", "FollowUp", fid, "Completed")
    db.session.commit()
    return redirect(request.referrer or url_for("dashboard"))


# ---------- jobs ----------
@app.route("/jobs")
@login_required
def jobs():
    rows = Job.query.order_by(Job.status.asc(), Job.id.desc()).all()
    workflows = Workflow.query.filter_by(active=True).order_by(Workflow.name).all()
    return render_template("jobs.html", rows=rows, workflows=workflows)


@app.route("/jobs/add", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def add_job():
    title = request.form.get("title", "").strip()
    if not title:
        flash("Job title is required.", "error")
        return redirect(url_for("jobs"))
    j = Job(title=title, location=request.form.get("location", ""), shift=request.form.get("shift", ""),
            recruiter=request.form.get("recruiter", ""), calendar_link=request.form.get("calendar_link", ""),
            jd_url=request.form.get("jd_url", ""), assessment_url=request.form.get("assessment_url", ""),
            workflow_id=request.form.get("workflow_id") or None)
    db.session.add(j)
    db.session.flush()
    audit("CREATE", "Job", j.id, j.title)
    db.session.commit()
    flash("Job created.")
    return redirect(url_for("jobs"))


@app.route("/jobs/<int:jid>/edit", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def edit_job(jid):
    j = Job.query.get_or_404(jid)
    j.title = request.form.get("title", j.title).strip() or j.title
    j.location = request.form.get("location", "")
    j.shift = request.form.get("shift", "")
    j.recruiter = request.form.get("recruiter", "")
    j.calendar_link = request.form.get("calendar_link", "")
    j.jd_url = request.form.get("jd_url", "")
    j.assessment_url = request.form.get("assessment_url", "")
    j.workflow_id = request.form.get("workflow_id") or None
    audit("UPDATE", "Job", jid, j.title)
    db.session.commit()
    flash("Job updated.")
    return redirect(url_for("jobs"))


@app.route("/jobs/<int:jid>/toggle", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def toggle_job(jid):
    j = Job.query.get_or_404(jid)
    j.status = "Closed" if j.status == "Open" else "Open"
    audit("UPDATE", "Job", jid, j.status)
    db.session.commit()
    return redirect(url_for("jobs"))


# ---------- import ----------
@app.route("/import", methods=["GET", "POST"])
@login_required
@role_required("Admin", "Recruiter")
def import_csv():
    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename.lower().endswith(".csv"):
            flash("Choose a CSV export from Google Sheets.", "error")
            return redirect(url_for("import_csv"))
        reader = csv.DictReader(io.StringIO(f.read().decode("utf-8-sig", errors="replace")))
        imported = matched = skipped = 0
        for r in reader:
            name = (r.get("Candidate Name") or r.get("Candidate") or "").strip()
            if not name:
                skipped += 1
                continue
            email = (r.get("Email ID") or r.get("Email") or "").strip()
            phone = (r.get("Phone Number") or r.get("Phone") or "").strip()
            c = find_candidate(email, phone)
            if c:
                matched += 1
                c.email = c.email or email
                c.normalized_email = norm_email(c.email)
                c.phone = c.phone or phone
                c.normalized_phone = norm_phone(c.phone)
            else:
                c = Candidate(name=name, email=email, normalized_email=norm_email(email), phone=phone, normalized_phone=norm_phone(phone))
                db.session.add(c)
                db.session.flush()
            status = (r.get("Status") or "Imported").strip()
            app_date = (r.get("Date") or str(date.today())).strip()
            a = Application(
                candidate_id=c.id, role=(r.get("Role") or "Imported").strip(), salary=r.get("Salary", ""),
                experience=r.get("Experience", ""), notice_period=r.get("Notice Period / Availability", ""),
                status=status, notes=r.get("Notes", ""), application_date=app_date,
                source=r.get("Source") or "Imported CSV", rp_ticket=(r.get("RP-Ticket") or r.get("RP Ticket") or "").strip(),
                source_link=r.get("Link") or r.get("URL") or ""
            )
            db.session.add(a)
            db.session.flush()
            rec, reason = recommendation(c.id)
            a.recommendation, a.recommendation_reason = rec, reason
            db.session.add(Event(candidate_id=c.id, application_id=a.id, stage=status, outcome="", reason="",
                                 notes=r.get("Notes", ""), event_date=app_date, created_by=session["user"]))
            imported += 1
        audit("IMPORT", "CSV", None, f"{imported} applications; {matched} matched; {skipped} skipped")
        db.session.commit()
        flash(f"Imported {imported} applications; matched {matched} to existing candidates; skipped {skipped} blank rows.")
        return redirect(url_for("candidates"))
    return render_template("import.html")


# ---------- settings/workflows/templates ----------
@app.route("/settings", methods=["GET", "POST"])
@login_required
@role_required("Admin")
def settings():
    keys = {
        "stages": DEFAULT_STAGES, "reasons": DEFAULT_REASONS, "outcomes": DEFAULT_OUTCOMES,
        "sources": DEFAULT_SOURCES, "hard_reasons": DEFAULT_HARD_REASONS, "review_reasons": DEFAULT_REVIEW_REASONS
    }
    if request.method == "POST":
        for key in keys:
            vals = [x.strip() for x in request.form.get(key, "").splitlines() if x.strip()]
            if vals:
                row = db.session.get(Setting, key) or Setting(key=key, value="")
                row.value = "|".join(vals)
                db.session.add(row)
        audit("UPDATE", "Settings", None, "Recruitment configuration changed")
        db.session.commit()
        flash("Settings saved.")
    return render_template(
        "settings.html",
        stage_text="\n".join(setting_list("stages", DEFAULT_STAGES)),
        reason_text="\n".join(setting_list("reasons", DEFAULT_REASONS)),
        outcome_text="\n".join(setting_list("outcomes", DEFAULT_OUTCOMES)),
        source_text="\n".join(setting_list("sources", DEFAULT_SOURCES)),
        hard_text="\n".join(setting_list("hard_reasons", DEFAULT_HARD_REASONS)),
        review_text="\n".join(setting_list("review_reasons", DEFAULT_REVIEW_REASONS)),
        workflows=Workflow.query.order_by(Workflow.name).all(), templates=EmailTemplate.query.order_by(EmailTemplate.name).all()
    )


@app.route("/settings/workflow/add", methods=["POST"])
@login_required
@role_required("Admin")
def add_workflow():
    name = request.form.get("name", "").strip()
    if not name or Workflow.query.filter_by(name=name).first():
        flash("Workflow name is missing or already exists.", "error")
        return redirect(url_for("settings"))
    w = Workflow(name=name)
    db.session.add(w)
    db.session.flush()
    for pos, stage_name in enumerate(setting_list("stages", DEFAULT_STAGES)):
        db.session.add(WorkflowStage(workflow_id=w.id, name=stage_name, position=pos))
    audit("CREATE", "Workflow", w.id, name)
    db.session.commit()
    flash("Workflow created.")
    return redirect(url_for("settings"))


@app.route("/settings/workflow/<int:wf_id>", methods=["GET", "POST"])
@login_required
@role_required("Admin")
def edit_workflow(wf_id):
    w = Workflow.query.get_or_404(wf_id)
    if request.method == "POST":
        names = [x.strip() for x in request.form.get("stage_names", "").splitlines() if x.strip()]
        if not names:
            flash("A workflow must contain at least one stage.", "error")
            return redirect(url_for("edit_workflow", wf_id=wf_id))
        WorkflowStage.query.filter_by(workflow_id=w.id).delete(synchronize_session=False)
        for pos, name in enumerate(names):
            db.session.add(WorkflowStage(workflow_id=w.id, name=name, position=pos))
        audit("UPDATE", "Workflow", w.id, f"{len(names)} stages")
        db.session.commit()
        flash("Workflow stages saved.")
        return redirect(url_for("settings"))
    return render_template("workflow.html", workflow=w)


@app.route("/settings/templates", methods=["GET", "POST"])
@login_required
@role_required("Admin")
def templates():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Template name is required.", "error")
            return redirect(url_for("templates"))
        t = EmailTemplate.query.filter_by(name=name).first() or EmailTemplate(name=name)
        t.subject = request.form.get("subject", "")
        t.html_body = request.form.get("html_body", "")
        t.text_body = request.form.get("text_body", "")
        db.session.add(t)
        db.session.flush()
        audit("UPSERT", "EmailTemplate", t.id, name)
        db.session.commit()
        flash("Email template saved.")
    return render_template("templates.html", templates=EmailTemplate.query.order_by(EmailTemplate.name).all())


# ---------- users/audit ----------
@app.route("/users", methods=["GET", "POST"])
@login_required
@role_required("Admin")
def users():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "Recruiter")
        if not username or len(password) < 10 or role not in USER_ROLES:
            flash("Username, a 10+ character password, and valid role are required.", "error")
        elif User.query.filter_by(username=username).first():
            flash("Username already exists.", "error")
        else:
            u = User(username=username, password_hash=generate_password_hash(password), role=role)
            db.session.add(u)
            db.session.flush()
            audit("CREATE", "User", u.id, username)
            db.session.commit()
            flash("User created.")
    return render_template("users.html", users=User.query.order_by(User.username).all(), roles=USER_ROLES)


@app.route("/users/<int:uid>/toggle", methods=["POST"])
@login_required
@role_required("Admin")
def toggle_user(uid):
    u = User.query.get_or_404(uid)
    if u.username == session.get("user"):
        flash("You cannot deactivate your own account.", "error")
    else:
        u.active = not u.active
        audit("UPDATE", "User", uid, "active=" + str(u.active))
        db.session.commit()
    return redirect(url_for("users"))


@app.route("/audit")
@login_required
@role_required("Admin")
def audit_page():
    page = max(request.args.get("page", 1, type=int), 1)
    pagination = AuditLog.query.order_by(AuditLog.id.desc()).paginate(page=page, per_page=50, error_out=False)
    return render_template("audit.html", logs=pagination.items, pagination=pagination)


# ---------- pipeline / exports ----------
@app.route("/pipeline")
@login_required
def pipeline():
    jobs = Job.query.filter_by(status="Open").order_by(Job.title).all()
    stages = setting_list("stages", DEFAULT_STAGES)
    cards = {}
    for job in jobs:
        cards[job.id] = {stage: Application.query.filter_by(job_id=job.id, status=stage).order_by(Application.updated_at.desc()).all() for stage in stages}
    return render_template("pipeline.html", jobs=jobs, stages=stages, cards=cards)

@app.route("/export/applications.csv")
@login_required
def export_applications():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Candidate Name","Email","Phone","Role","Job","Salary","Experience","Notice Period","Status","Recommendation","Recommendation Reason","Source","RP-Ticket","Source Link","Application Date","Notes"])
    for a in Application.query.join(Candidate).order_by(Application.id.desc()).all():
        writer.writerow([a.candidate.name,a.candidate.email,a.candidate.phone,a.role,a.job.title if a.job else "",a.salary,a.experience,a.notice_period,a.status,a.recommendation,a.recommendation_reason,a.source,a.rp_ticket,a.source_link,a.application_date,a.notes])
    response = app.response_class(output.getvalue(), mimetype="text/csv")
    response.headers["Content-Disposition"] = "attachment; filename=hire_reactor_applications.csv"
    return response

# ---------- integration API ----------
def queue_action(action_type, payload):
    db.session.add(IntegrationAction(action_type=action_type, payload=json.dumps(payload), status="PENDING"))


@app.route("/api/interviews/<int:iid>", methods=["POST"])
def update_interview_api(iid):
    if not valid_integration_token():
        abort(401)
    interview = Interview.query.get_or_404(iid)
    data = request.get_json(silent=True) or {}
    if "calendar_event_id" in data:
        interview.calendar_event_id = str(data.get("calendar_event_id") or "")
    if "status" in data:
        interview.status = str(data.get("status") or interview.status)
    db.session.commit()
    return jsonify({"ok": True, "interview_id": iid, "calendar_event_id": interview.calendar_event_id, "status": interview.status})

@app.route("/api/lookup")
def lookup():
    if not current_user() and not valid_integration_token():
        abort(401)
    c = find_candidate(request.args.get("email", ""), request.args.get("phone", ""))
    if not c:
        return jsonify({"found": False})
    rec = recommendation(c.id)
    return jsonify({
        "found": True, "candidate_id": c.id, "name": c.name, "email": c.email, "phone": c.phone,
        "recommendation": rec[0], "message": rec[1],
        "applications": [{"id": a.id, "role": a.role, "status": a.status, "source": a.source,
                          "date": a.application_date, "recommendation": a.recommendation,
                          "recommendation_reason": a.recommendation_reason} for a in c.applications],
        "history": [{"stage": e.stage, "outcome": e.outcome, "reason": e.reason, "date": e.event_date, "notes": e.notes} for e in history_for(c.id)[:100]]
    })


@app.route("/api/actions/pull")
def pull_actions():
    if not valid_integration_token():
        abort(401)
    # Claim work before returning it so two bridge executions cannot process the
    # same action concurrently. Failed/processing actions are recoverable.
    now = datetime.utcnow()
    stale_before = now - timedelta(minutes=15)
    db.session.query(IntegrationAction).filter(
        IntegrationAction.status == "PROCESSING",
        IntegrationAction.processed_at.is_(None),
        IntegrationAction.created_at < stale_before
    ).update({"status": "PENDING"}, synchronize_session=False)
    rows = IntegrationAction.query.filter_by(status="PENDING").order_by(IntegrationAction.id).limit(20).all()
    for row in rows:
        row.status = "PROCESSING"
        row.attempts += 1
    db.session.commit()
    return jsonify({"actions": [{"id": x.id, "type": x.action_type, "payload": json.loads(x.payload), "attempts": x.attempts} for x in rows]})


@app.route("/api/actions/<int:aid>/complete", methods=["POST"])
def complete_action_api(aid):
    if not valid_integration_token():
        abort(401)
    a = IntegrationAction.query.get_or_404(aid)
    a.status = "DONE"
    a.result = json.dumps(request.get_json(silent=True) or {})
    a.processed_at = datetime.utcnow()
    if a.action_type == "CALENDAR_CREATE":
        payload = json.loads(a.payload)
        interview = Interview.query.get(payload.get("interview_id"))
        result = request.get_json(silent=True) or {}
        if interview and result.get("calendar_event_id"):
            interview.calendar_event_id = result["calendar_event_id"]
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/actions/<int:aid>/fail", methods=["POST"])
def fail_action_api(aid):
    if not valid_integration_token():
        abort(401)
    a = IntegrationAction.query.get_or_404(aid)
    a.status = "FAILED"
    a.result = json.dumps(request.get_json(silent=True) or {})
    a.processed_at = datetime.utcnow()
    db.session.commit()
    return jsonify({"ok": True})


@app.route("/api/sheet/event", methods=["POST"])
def sheet_event():
    if not valid_integration_token():
        abort(401)
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip()
    phone = str(data.get("phone", "")).strip()
    if not name:
        return jsonify({"ok": False, "error": "name required"}), 400
    c = find_candidate(email, phone)
    created = not bool(c)
    if not c:
        c = Candidate(name=name, email=email, normalized_email=norm_email(email), phone=phone, normalized_phone=norm_phone(phone))
        db.session.add(c)
        db.session.flush()
    else:
        c.email = c.email or email
        c.normalized_email = norm_email(c.email)
        c.phone = c.phone or phone
        c.normalized_phone = norm_phone(c.phone)
    status = str(data.get("status") or "New Application")
    role = str(data.get("role") or data.get("sheetName") or "Imported from Sheet")
    rp = str(data.get("rp_ticket") or data.get("rpTicket") or "").strip()
    app_row = Application.query.filter_by(rp_ticket=rp).first() if rp else None
    if not app_row:
        app_row = Application.query.filter_by(candidate_id=c.id, role=role, application_date=str(data.get("date") or date.today())).order_by(Application.id.desc()).first()
    if not app_row:
        app_row = Application(candidate_id=c.id, role=role, application_date=str(data.get("date") or date.today()), source=str(data.get("source") or "Google Sheet"))
        db.session.add(app_row)
        db.session.flush()
    app_row.salary = str(data.get("salary", ""))
    app_row.experience = str(data.get("experience", ""))
    app_row.notice_period = str(data.get("notice", ""))
    app_row.status = status
    app_row.notes = str(data.get("notes", ""))
    app_row.rp_ticket = rp
    app_row.source_link = str(data.get("link", ""))
    refresh_application_recommendation(app_row)
    event_date = str(data.get("date") or date.today())
    event_notes = str(data.get("notes", ""))
    duplicate_event = Event.query.filter_by(candidate_id=c.id, application_id=app_row.id, stage=status, event_date=event_date, notes=event_notes, created_by="Google Sheets").first()
    if not duplicate_event:
        db.session.add(Event(candidate_id=c.id, application_id=app_row.id, stage=status, outcome="", reason="",
                             notes=event_notes, event_date=event_date, created_by="Google Sheets"))
    audit("SYNC", "Sheet", app_row.id, f"{email} / {status}" + (" / duplicate event skipped" if duplicate_event else ""))
    db.session.commit()
    return jsonify({"ok": True, "candidate_id": c.id, "application_id": app_row.id, "created_candidate": created,
                    "recommendation": app_row.recommendation, "reason": app_row.recommendation_reason})



@app.route("/integrations", methods=["GET"])
@login_required
@role_required("Admin", "Recruiter")
def integrations_page():
    pending = IntegrationAction.query.filter_by(status="PENDING").count()
    processing = IntegrationAction.query.filter_by(status="PROCESSING").count()
    failed = IntegrationAction.query.filter_by(status="FAILED").count()
    done = IntegrationAction.query.filter_by(status="DONE").order_by(IntegrationAction.processed_at.desc()).limit(10).all()
    return render_template("integrations.html", pending=pending, processing=processing, failed=failed, done=done)

@app.route("/candidate/<int:cid>/email", methods=["POST"])
@login_required
@role_required("Admin", "Recruiter")
def queue_candidate_email(cid):
    c = Candidate.query.get_or_404(cid)
    aid = request.form.get("application_id", type=int)
    a = Application.query.get_or_404(aid) if aid else None
    if a and a.candidate_id != cid:
        abort(400)
    recipient = (c.email or "").strip()
    if not recipient:
        flash("Candidate does not have an email address.", "error")
        return redirect(url_for("candidate", cid=cid))
    kind = request.form.get("kind", "GENERAL")
    subject = request.form.get("subject", "Hire Reactor — Recruitment Update").strip()
    html = request.form.get("html_body", "").strip()
    text = request.form.get("text_body", "").strip() or re.sub(r"<[^>]+>", "", html)
    if not html and not text:
        flash("Email body is required.", "error")
        return redirect(url_for("candidate", cid=cid))
    payload = {
        "kind": kind,
        "to": recipient,
        "candidate_id": cid,
        "candidate_name": c.name,
        "application_id": a.id if a else None,
        "role": a.role if a else "",
        "subject": subject,
        "html_body": html or f"<p>{text}</p>",
        "text_body": text,
        "reply_to": os.environ.get("HR_REPLY_TO", ""),
        "sender_name": os.environ.get("HR_SENDER_NAME", "Hire Reactor Recruitment"),
    }
    queue_action("EMAIL_SEND", payload)
    audit("QUEUE", "Email", cid, f"{kind} to {recipient}")
    db.session.commit()
    flash(f"{kind.replace('_',' ').title()} email queued. Google Apps Script will send it.")
    return redirect(url_for("candidate", cid=cid))

@app.route("/api/calendar/event-sync", methods=["POST"])
def calendar_event_sync():
    if not valid_integration_token():
        abort(401)
    data = request.get_json(silent=True) or {}
    event_id = str(data.get("event_id") or "").strip()
    if not event_id:
        return jsonify({"ok": False, "error": "event_id required"}), 400
    status = str(data.get("status") or "confirmed").lower()
    # A cancelled event is retained in history but marked cancelled.
    event_status = "Cancelled" if status == "cancelled" else "Scheduled"
    application_id = None
    marker = str(data.get("application_id") or "").strip()
    if marker.isdigit():
        application_id = int(marker)
    c = None
    if not application_id:
        emails = [norm_email(x) for x in (data.get("attendees") or []) if x]
        emails += [norm_email(data.get("candidate_email"))] if data.get("candidate_email") else []
        emails = [x for x in emails if x]
        for em in emails:
            c = Candidate.query.filter_by(normalized_email=em).first()
            if c:
                break
        if c:
            candidates_apps = Application.query.filter_by(candidate_id=c.id).order_by(Application.id.desc()).all()
            if candidates_apps:
                # Prefer an existing interview with this event, then the most recent active application.
                existing = Interview.query.filter_by(calendar_event_id=event_id).first()
                if existing:
                    application_id = existing.application_id
                else:
                    active = [x for x in candidates_apps if x.status not in ("Rejected", "Closed", "DO NOT PROCEED")]
                    application_id = (active or candidates_apps)[0].id
    a = Application.query.get(application_id) if application_id else None
    if not a and c:
        a = Application.query.filter_by(candidate_id=c.id).order_by(Application.id.desc()).first()
    if not a:
        return jsonify({"ok": True, "matched": False, "event_id": event_id})
    existing = Interview.query.filter_by(calendar_event_id=event_id).first()
    start = str(data.get("start") or "")
    end = str(data.get("end") or "")
    meeting = str(data.get("meeting_link") or "")
    if existing:
        i = existing
    else:
        i = Interview(application_id=a.id, calendar_event_id=event_id, interview_type=str(data.get("interview_type") or "Interview"), created_by="Google Calendar")
        db.session.add(i)
    i.scheduled_at = start
    i.meeting_link = meeting
    i.interviewer = str(data.get("organizer") or i.interviewer or "")
    i.status = event_status
    i.notes = (i.notes or "") + ("\nGoogle Calendar sync: " + str(data.get("html_link") or "")).strip()
    if event_status == "Scheduled":
        a.status = a.status if a.status not in ("New Application", "") else "Interview Scheduled"
        refresh_application_recommendation(a)
    audit("SYNC", "Calendar", i.id, f"Event {event_id} → application {a.id}")
    db.session.commit()
    return jsonify({"ok": True, "matched": True, "interview_id": i.id, "application_id": a.id, "calendar_event_id": event_id, "status": i.status, "start": start, "end": end})

@app.route("/api/integrations/status")
def integration_status_api():
    if not current_user() and not valid_integration_token():
        abort(401)
    return jsonify({
        "pending": IntegrationAction.query.filter_by(status="PENDING").count(),
        "processing": IntegrationAction.query.filter_by(status="PROCESSING").count(),
        "failed": IntegrationAction.query.filter_by(status="FAILED").count(),
        "done": IntegrationAction.query.filter_by(status="DONE").count(),
    })

@app.route("/health")
def health():
    try:
        db.session.execute(db.text("SELECT 1"))
        return jsonify({"status": "ok", "database": "ok", "time": datetime.utcnow().isoformat() + "Z"})
    except Exception:
        return jsonify({"status": "degraded", "database": "error"}), 503


@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="You do not have permission to access this page."), 403


@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="The requested page was not found."), 404


@app.errorhandler(413)
def too_large(_):
    return render_template("error.html", code=413, message="The uploaded file is too large."), 413


# Local/dev bootstrap. Production uses Flask-Migrate and bootstrap.py after migrations.
if env_bool("HR_AUTO_INIT_DB", not env_bool("HR_PRODUCTION", False)):
  with app.app_context():
      db.create_all()
      defaults = {
          "stages": DEFAULT_STAGES, "reasons": DEFAULT_REASONS, "outcomes": DEFAULT_OUTCOMES,
          "sources": DEFAULT_SOURCES, "hard_reasons": DEFAULT_HARD_REASONS, "review_reasons": DEFAULT_REVIEW_REASONS
      }
      for key, values in defaults.items():
          if not db.session.get(Setting, key):
              db.session.add(Setting(key=key, value="|".join(values)))
      if not User.query.filter_by(username="admin").first():
          password = os.environ.get("HR_ADMIN_PASSWORD")
          if not password and env_bool("HR_PRODUCTION", False):
              raise RuntimeError("HR_ADMIN_PASSWORD must be set in production for first bootstrap")
          db.session.add(User(username="admin", password_hash=generate_password_hash(password or "ChangeMe123!"), role="Admin"))
      if not Workflow.query.first():
          workflow = Workflow(name="Default Workflow")
          db.session.add(workflow)
          db.session.flush()
          for position, stage_name in enumerate(DEFAULT_STAGES):
              db.session.add(WorkflowStage(workflow_id=workflow.id, name=stage_name, position=position))
      db.session.commit()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
